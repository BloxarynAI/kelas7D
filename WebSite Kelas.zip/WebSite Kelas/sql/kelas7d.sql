CREATE DATABASE kelas7d;
USE kelas7d;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) UNIQUE,
  fullname VARCHAR(100),
  password VARCHAR(255),
  role ENUM('admin','user') DEFAULT 'user',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE announcements (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255),
  content TEXT,
  author VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE login_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50),
  time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Admin default
INSERT INTO users (username, fullname, password, role) 
VALUES ('Admin', 'Administrator Utama', MD5('owner'), 'admin');